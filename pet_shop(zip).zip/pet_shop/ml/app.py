from flask import Flask, render_template,request
import pandas as pd

app = Flask(__name__)

@app.route('/')
def dem():
    return render_template('dem.html')

@app.route('/', methods=['POST','GET'])
def gervalue():
    desp = request.form['desp']
    df=pd.read_csv('C:/xampp/htdocs/pet_shop/ml/petdata.csv')
    df_baskets = df[['InvoiceNo', 'StockCode', 'Description', 'Quantity']]
    df.groupby('Description').agg(
        orders=('InvoiceNo', 'nunique'),
        quantity=('Quantity', 'sum')
    ).sort_values(by='orders', ascending=False).head(10)
    df_items = df_baskets.pivot_table(index='InvoiceNo', columns=['Description'], values='Quantity').fillna(0)
    def get_recommendations(df, item):
        """Generate a set of product recommendations using item-based collaborative filtering.
    
        Args:
        df (dataframe): Pandas dataframe containing matrix of items purchased.
        item (string): Column name for target item. 
        
        Returns: 
        recommendations (dataframe): Pandas dataframe containing product recommendations. 
        """
                                                              
        recommendations = df.corrwith(df[item])
        recommendations.dropna(inplace=True)
        recommendations = pd.DataFrame(recommendations, columns=['correlation']).reset_index()
        recommendations = recommendations.sort_values(by='correlation', ascending=False)
    
        return recommendations
    
    recommendations = get_recommendations(df_items, desp)
    recommendations.to_html("ml/templates/index.html")
    
    if desp=='Purepet Chew Bone':
        rect1=recommendations.loc[8,'Description']
        rect2=recommendations.loc[7,'Description']
        rect3=recommendations.loc[6,'Description']
        rect4=recommendations.loc[9,'Description']
        rect5=recommendations.loc[2,'Description']
        rect6=recommendations.loc[1,'Description']
        rect7=recommendations.loc[3,'Description']
        rect8=recommendations.loc[4,'Description']
        rect9=recommendations.loc[10,'Description']

    elif desp=='Dog Bed':
        rect1=recommendations.loc[6,'Description']
        rect2=recommendations.loc[9,'Description']
        rect3=recommendations.loc[1,'Description']
        rect4=recommendations.loc[3,'Description']
        rect5=recommendations.loc[7,'Description']
        rect6=recommendations.loc[8,'Description']
        rect7=recommendations.loc[0,'Description']
        rect8=recommendations.loc[2,'Description']
        rect9=recommendations.loc[5,'Description']
    
    elif desp=='Dog Belt':
        rect1=recommendations.loc[7,'Description']
        rect2=recommendations.loc[1,'Description']
        rect3=recommendations.loc[8,'Description']
        rect4=recommendations.loc[6,'Description']
        rect5=recommendations.loc[3,'Description']
        rect6=recommendations.loc[9,'Description']
        rect7=recommendations.loc[4,'Description']
        rect8=recommendations.loc[5,'Description']
        rect9=recommendations.loc[10,'Description']
    
    elif desp=='Bird Cage':
        rect1=recommendations.loc[1,'Description']
        rect2=recommendations.loc[7,'Description']
        rect3=recommendations.loc[6,'Description']
        rect4=recommendations.loc[9,'Description']
        rect5=recommendations.loc[5,'Description']
        rect6=recommendations.loc[10,'Description']
        rect7=recommendations.loc[2,'Description']
        rect8=recommendations.loc[3,'Description']
        rect9=recommendations.loc[8,'Description']

    elif desp=='Pedigree Meat & Rice':
        rect1=recommendations.loc[9,'Description']
        rect2=recommendations.loc[6,'Description']
        rect3=recommendations.loc[4,'Description']
        rect3=recommendations.loc[1,'Description']
        rect4=recommendations.loc[8,'Description']
        rect5=recommendations.loc[3,'Description']
        rect6=recommendations.loc[5,'Description']
        rect7=recommendations.loc[10,'Description']
        rect8=recommendations.loc[2,'Description']
        rect9=recommendations.loc[7,'Description']
    
    elif desp=='Orijen Cat and Kitten Food':
        rect1=recommendations.loc[5,'Description']
        rect2=recommendations.loc[2,'Description']
        rect3=recommendations.loc[1,'Description']
        rect4=recommendations.loc[9,'Description']
        rect5=recommendations.loc[4,'Description']
        rect6=recommendations.loc[3,'Description']
        rect7=recommendations.loc[6,'Description']
        rect8=recommendations.loc[10,'Description']
        rect9=recommendations.loc[7,'Description']

    elif desp=='Cat Belt':
        rect1=recommendations.loc[4,'Description']
        rect2=recommendations.loc[9,'Description']
        rect3=recommendations.loc[5,'Description']
        rect4=recommendations.loc[3,'Description']
        rect5=recommendations.loc[10,'Description']
        rect6=recommendations.loc[8,'Description']
        rect7=recommendations.loc[7,'Description']
        rect8=recommendations.loc[1,'Description']
        rect9=recommendations.loc[6,'Description']

    elif desp=='Toya Bird Food':
        rect1=recommendations.loc[2,'Description']
        rect2=recommendations.loc[5,'Description']
        rect3=recommendations.loc[6,'Description']
        rect4=recommendations.loc[1,'Description']
        rect5=recommendations.loc[8,'Description']
        rect6=recommendations.loc[9,'Description']
        rect7=recommendations.loc[10,'Description']
        rect8=recommendations.loc[3,'Description']
        rect9=recommendations.loc[4,'Description']
    
    elif desp=='Fish Tank':
        rect1=recommendations.loc[10,'Description']
        rect2=recommendations.loc[1,'Description']
        rect3=recommendations.loc[9,'Description']
        rect4=recommendations.loc[4,'Description']
        rect5=recommendations.loc[6,'Description']
        rect6=recommendations.loc[2,'Description']
        rect7=recommendations.loc[5,'Description']
        rect8=recommendations.loc[8,'Description']
        rect9=recommendations.loc[7,'Description']
    
    return render_template('recomendation.html',desp= desp,rect1=rect1,rect2=rect2,rect3=rect3,rect4=rect4,rect5=rect5,rect6=rect6,rect7=rect7,rect8=rect8,rect9=rect9)
@app.route('/index')
def index():
    return render_template('index.html')


@app.route('/recommendation')
def recomendationpage():
    return render_template('recomendation.html')


if __name__ == '__main__':
    app.debug = True
    app.run()